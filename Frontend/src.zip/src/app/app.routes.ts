import { Routes } from '@angular/router';

export const routes: Routes = [
    {
        path: '',
        loadComponent: () =>
            import('./home/home').then(m => m.Home)
    },
    {
        path: 'auth',
        loadChildren: () =>
            import('./features/auth/auth.routes').then(m => m.AUTH_ROUTES)
    },
    {
        path: 'lobby',
        loadChildren: () =>
            import('./features/lobby/lobby.routes').then(m => m.LOBBY_ROUTES)
    },
    {
        path: 'game',
        loadChildren: () =>
            import('./features/game/game.routes').then(m => m.GAME_ROUTES)
    },
    {
        path: 'movies',
        loadComponent: () => import('./features/movie-selection/movie-selection').then(m => m.MovieSelection)
    },
    { path: '**', redirectTo: '' }
];
