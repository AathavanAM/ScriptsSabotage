import { Injectable, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({ providedIn: 'root' })
export class TmdbService {
  apiKey = 'YOUR_TMDB_API_KEY';
  baseUrl = 'https://api.themoviedb.org/3';

  movies = signal<any[]>([]);

  constructor(private http: HttpClient) { }

  getMovies(language: string, yearRange: string) {
    const [start, end] = yearRange.split('-');
    return this.http
      .get(`${this.baseUrl}/discover/movie`, {
        params: {
          api_key: this.apiKey,
          with_original_language: language,
          primary_release_date_gte: `${start}-01-01`,
          primary_release_date_lte: `${end}-12-31`,
          sort_by: 'popularity.desc'
        },
      })
      .subscribe((res: any) => this.movies.set(res.results));
  }
}