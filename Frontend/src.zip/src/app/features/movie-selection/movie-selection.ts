import { Component, OnInit } from '@angular/core';
import { CommonModule, NgForOf, NgIf } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MovieService, Movie } from '../../core/services/movie.service';
import { AuthService } from '../../core/services/auth.service';
import { HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-movie-selection',
  standalone: true,
  imports: [CommonModule, FormsModule, HttpClientModule, NgIf, NgForOf],
  templateUrl: './movie-selection.html',
  styleUrls: ['./movie-selection.scss'],
})
export class MovieSelection implements OnInit {
  // form
  language = ''; // ISO 639-1 code (e.g., 'en', 'hi', 'fr')
  yearFrom = new Date().getFullYear() - 10;
  yearTo = new Date().getFullYear();
  page = 1;

  // state
  loading = false;
  movies: Movie[] = [];
  selectedMovieIds = new Set<number>();
  maxSelectable = 10; // default allowed to save
  userId: string | null = null;
  error = '';

  constructor(private movieService: MovieService, private auth: AuthService) { }

  ngOnInit(): void {
    this.userId = this.auth.getUserId();
    // Load previously saved movies for this user (if any)
    if (this.userId) {
      const existing = this.movieService.getUserMovies(this.userId);
      if (existing && existing.length) {
        // show small preview — don't auto-select
      }
    }
  }

  fetch() {
    if (!this.language) {
      this.error = 'Please select a language.';
      return;
    }
    if (this.yearFrom > this.yearTo) {
      this.error = 'Year from cannot be greater than year to.';
      return;
    }

    this.error = '';
    this.loading = true;
    this.movieService.discoverMovies(this.language, this.yearFrom, this.yearTo, this.page)
      .subscribe({
        next: (res) => {
          this.movies = res.results || [];
          this.loading = false;
          this.selectedMovieIds.clear();
        },
        error: (err) => {
          this.loading = false;
          this.error = 'Failed to fetch movies. Check your API key or network.';
          console.error(err);
        }
      });
  }

  toggleSelect(m: Movie) {
    if (this.selectedMovieIds.has(m.id)) {
      this.selectedMovieIds.delete(m.id);
    } else {
      if (this.selectedMovieIds.size >= this.maxSelectable) {
        alert(`You can only select up to ${this.maxSelectable} movies.`);
        return;
      }
      this.selectedMovieIds.add(m.id);
    }
  }

  saveSelections() {
    if (!this.userId) {
      alert('User not authenticated. Please login.');
      return;
    }
    const chosen = this.movies.filter(m => this.selectedMovieIds.has(m.id));
    if (!chosen.length) {
      alert('Select at least one movie to save.');
      return;
    }
    // Save full movie objects for later aggregation
    this.movieService.saveUserMovies(this.userId, chosen);
    alert('Saved ' + chosen.length + ' movies to your profile.');
  }

  posterUrl(p?: string | null) {
    return this.movieService.posterUrl(p);
  }

  // helper to set number of max selectable movies dynamically
  setMax(nStr: string) {
    const n = Number(nStr);
    if (isNaN(n) || n < 1) return;
    this.maxSelectable = Math.min(100, n); // sane upper limit
  }
}