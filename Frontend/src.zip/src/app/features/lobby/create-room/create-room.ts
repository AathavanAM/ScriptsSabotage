import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { LobbyService } from '../lobby.service';
import { SocketService } from '../../../core/socket.service';

@Component({
  selector: 'app-create-room',
  standalone: true,
  imports: [RouterModule],
  templateUrl: './create-room.html',
  styleUrls: ['./create-room.scss']
})
export class CreateRoom {

  roomCode: string = '';

  constructor(private lobby: LobbyService, private socket: SocketService) { }

  generateRoom() {
    this.roomCode = this.lobby.generateRoomCode();
    this.socket.connect();

    this.socket.emit('create-room', { roomCode: this.roomCode });
  }
}