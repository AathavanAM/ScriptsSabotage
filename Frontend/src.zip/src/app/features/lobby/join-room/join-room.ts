import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { SocketService } from '../../../core/socket.service';

@Component({
  selector: 'app-join-room',
  standalone: true,
  imports: [FormsModule, RouterModule],
  templateUrl: './join-room.html',
  styleUrls: ['./join-room.scss']
})
export class JoinRoom {
  roomCode: string = '';

  constructor(private socket: SocketService) { }

  join() {
    if (!this.roomCode || this.roomCode.length < 5) {
      alert('Enter a valid room code');
      return;
    }

    this.socket.connect();
    this.socket.emit('join-room', { roomCode: this.roomCode });

    console.log('Joining room:', this.roomCode);
  }
}