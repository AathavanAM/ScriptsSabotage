import { Routes } from '@angular/router';

export const GAME_ROUTES: Routes = [
    {
        path: '',
        loadComponent: () =>
            import('./game-screen/game-screen').then(m => m.GameScreen)
    },
    {
        path: ':roomCode',
        loadComponent: () =>
            import('./game-screen/game-screen').then(m => m.GameScreen)
    }
];