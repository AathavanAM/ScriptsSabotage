import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../../core/services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './login.html',
  styleUrls: ['./login.scss']
})
export class Login {

  mobile = '';
  password = '';
  errorMsg = '';

  constructor(
    private auth: AuthService,
    private router: Router
  ) { }

  submitLogin() {
    if (!this.mobile || !this.password) {
      this.errorMsg = 'Please enter all fields';
      return;
    }

    // temporary mock logic
    const fakeToken = 'sample-token';
    const fakeUserId = 'user-' + this.mobile;

    this.auth.login(fakeToken, fakeUserId);
    this.router.navigate(['/home']);
  }
}