import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './register.html',
  styleUrls: ['./register.scss']
})
export class Register {

  mobile = '';
  username = '';
  gender = '';
  password = '';
  errorMsg = '';

  constructor(
    private auth: AuthService,
    private router: Router
  ) { }

  submitRegister() {
    if (!this.mobile || !this.username || !this.gender || !this.password) {
      this.errorMsg = 'Please fill all fields';
      return;
    }

    // Simulating user id creation
    const fakeToken = 'token-' + this.mobile;
    const fakeUserId = 'user-' + this.mobile;

    this.auth.login(fakeToken, fakeUserId);
    this.router.navigate(['/home']);
  }
}