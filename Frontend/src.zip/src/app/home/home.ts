import { Component, OnInit } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { AuthService } from '../core/services/auth.service';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [RouterModule],
  templateUrl: './home.html',
  styleUrls: ['./home.scss']
})
export class Home implements OnInit {

  userId: string | null = null;

  constructor(private auth: AuthService, private router: Router) { }

  ngOnInit(): void {
    this.userId = this.auth.getUserId();

    if (!this.userId) {
      this.router.navigate(['/auth/login']);
    }
  }

  gotoCreateRoom() {
    this.router.navigate(['/lobby/create']);
  }

  gotoJoinRoom() {
    this.router.navigate(['/lobby/join']);
  }
}