import { Injectable, signal } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  getUserId(): string | null {
    throw new Error('Method not implemented.');
  }

  // Store authentication state using Angular Signals
  private readonly _isLoggedIn = signal<boolean>(false);
  private readonly _token = signal<string | null>(null);
  private readonly _userId = signal<string | null>(null);

  constructor() {
    this.loadFromLocalStorage();
  }

  // Expose Signals as readonly
  isLoggedIn = this._isLoggedIn.asReadonly();
  token = this._token.asReadonly();
  userId = this._userId.asReadonly();

  // Save login data
  login(token: string, userId: string): void {
    this._isLoggedIn.set(true);
    this._token.set(token);
    this._userId.set(userId);

    localStorage.setItem('token', token);
    localStorage.setItem('userId', userId);
    localStorage.setItem('isLoggedIn', 'true');
  }

  // Logout user
  logout(): void {
    this._isLoggedIn.set(false);
    this._token.set(null);
    this._userId.set(null);

    localStorage.removeItem('token');
    localStorage.removeItem('userId');
    localStorage.removeItem('isLoggedIn');
  }

  // Check and load from localStorage
  private loadFromLocalStorage(): void {
    const token = localStorage.getItem('token');
    const userId = localStorage.getItem('userId');
    const loggedIn = localStorage.getItem('isLoggedIn') === 'true';

    if (loggedIn && token && userId) {
      this._token.set(token);
      this._userId.set(userId);
      this._isLoggedIn.set(true);
    }
  }
}