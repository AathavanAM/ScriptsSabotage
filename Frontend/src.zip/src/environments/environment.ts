export const environment = {
    production: false,
    tmdbApiKey: '<YOUR_TMDB_API_KEY>',
    tmdbBaseUrl: 'https://api.themoviedb.org/3',
    tmdbImageBase: 'https://image.tmdb.org/t/p/w200'
};